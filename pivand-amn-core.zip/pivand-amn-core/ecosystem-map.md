# نقشه‌ی اکوسیستم پیوند امن

> این فایل قبلاً در کامنت‌های کد (مثلاً `pivand-amn-quiz-enterprise.php`) ارجاع
> داده می‌شد ولی هیچ‌وقت واقعاً ساخته نشده بود. این نسخه، منبع واحد و
> انسان‌خوان وضعیت فعلی اکوسیستم است — نسخه‌ی ماشین‌خوان همین اطلاعات در
> `includes/class-filter-registry.php` (همین پلاگین، core) و صفحه‌ی
> «زیرساخت پیوند امن» در پیشخوان وردپرس زنده نگه داشته می‌شود؛ اگر این دو جا
> با هم ناهم‌خوان شدند، رجیستری در کد منبع درست است، نه این فایل.

## پلاگین‌ها

| # | پلاگین | نقش | باید همیشه فعال باشد؟ |
|---|---|---|---|
| 01 | pivand-amn-core | زیرساخت مشترک: نرمال‌سازی موبایل/IP، رمزنگاری، تقویم شمسی، رجیستری وابستگی و قراردادها | ✅ بله، قبل از بقیه |
| 02 | pivand-amn-2fa | احراز دومرحله‌ای (TOTP) برای ورود ادمین | اختیاری per-user |
| 03 | pivand-amn-smtp-mailer | تنظیمات SMTP خروجی وردپرس | مستقل |
| 04 | pivand-amn-sms-bridge | تنها اتصال واقعی به ملی‌پیامک؛ ارائه‌دهنده‌ی `pas_send_sms` | اگر client-portal فعال است، بله |
| 05 | pivand-amn-case-file | پرونده بالینی مراجعین (رمزنگاری‌شده) | مستقل، ولی بهتر با core |
| 06 | pivand-amn-quiz-enterprise | آزمون‌های روان‌سنجی؛ ارائه‌دهنده‌ی سه قرارداد `psy_get_*_for_phone` | اگر case-file/client-portal به نتایج آزمون نیاز دارند، بله |
| 07 | pivand-amn-client-portal | پنل مراجعان زوج‌درمان، نوبت‌دهی، پرداخت (زرین‌پال) | هسته‌ی اصلی تعامل با مراجع |
| 08 | payvand-contact | فرم تماس عمومی سایت | مستقل |
| 09 | pivand-amn-content-writer | تولید محتوا و سئو با AI (ادغام‌شده از Peyvand Amn SEO Assistant Pro) | مستقل |
| 10 | piwand-daily-feed | کارت‌های محتوای روزانه (فید/اسلایدر) | مستقل |

## قراردادهای فیلتری بین‌افزونه‌ای

فهرست کامل و به‌روز همیشه در `Pas_Core_Filter_Registry::contracts()` است
(پلاگین 01) و در پیشخوان زیر منوی «زیرساخت پیوند امن» قابل مشاهده است.
خلاصه‌ی فعلی:

- `pas_send_sms` — تولیدکننده: sms-bridge (04) ← مصرف‌کننده: client-portal (07)
- `psy_get_pending_quizzes_for_phone` — تولیدکننده: quiz-enterprise (06) ← مصرف‌کننده: client-portal (07)
- `psy_get_client_name_for_phone` — تولیدکننده: quiz-enterprise (06) ← مصرف‌کننده: client-portal (07)
- `psy_get_completed_results_for_phone` — تولیدکننده: quiz-enterprise (06) ← مصرف‌کننده: case-file (05)
- `pas_get_case_summary_for_phone` — تولیدکننده: case-file (05) ← مصرف‌کننده: client-portal (07، تب لیدها)
- `zdp_get_intake_for_phone` — تولیدکننده: client-portal (07) ← مصرف‌کننده: case-file (05، کارت فرم ارزیابی)
- `pas_lookup_known_client_name` — زنجیره‌ای: client-portal (۵) ← case-file (۱۰) ← quiz-enterprise (۱۵)

## نگه‌داری این فایل

هر وقت قرارداد فیلتری جدیدی بین دو پلاگین از این خانواده اضافه شد، هم
`class-filter-registry.php` و هم این فایل باید به‌روزرسانی شوند.

## رجیستری‌های دیگر (اضافه‌شده در 01/core نسخه‌ی ۱.۲.۰)

سه رجیستری مستندسازی دیگر هم در همین پلاگین (core) اضافه شد و در صفحه‌ی
«زیرساخت پیوند امن» پیشخوان قابل مشاهده‌اند — هر سه فقط اطلاعاتی‌اند، هیچ‌کدام
رفتار runtime را تغییر نمی‌دهند:

- `class-table-registry.php` (`Pas_Core_Table_Registry`) — نگاشت پیشوند/نام
  جدول‌های دیتابیس هر پلاگین (هفت پیشوند: `zdp_`, `psy_`, `pas_`, `pas_cf_`,
  `aco_`, `pwdf_`, `payvand_`)، به‌علاوه علامت‌گذاری جدول‌های میراث `cpp_*`
  که فقط برای migration نگه داشته شده‌اند.
- `class-capability-registry.php` (`Pas_Core_Capability_Registry`) — نگاشت
  کپابیلیتی‌های سفارشی (`zdp_manage_clients`, `pas_manage_case_files`,
  `pas_view_all_case_files`) و نقش‌هایی که فعلاً آن‌ها را دارند.
- `class-prefix-map.php` (`Pas_Core_Prefix_Map`) — نگاشت پیشوند کلاس به
  پلاگین صاحب آن (شش قاعده‌ی نام‌گذاری هم‌زمان در اکوسیستم: `Pas_Core_`,
  `Pas_CF_`, `Pas_`, `Psy_`, `ACO_`, `PWDF_`, `ZSM_`، به‌علاوه دو namespace
  مدرن `ZoojDarman\ClientPortal` و `Pivand\SmtpMailer`).

هر سه از همان الگوی self-registration پیروی می‌کنند که `class-dependency-checker.php`
دارد؛ فعلاً core خودش نمایندگی همه‌ی پلاگین‌های شناخته‌شده را در بوت‌استرپ
(`pivand-amn-core.php`) ثبت می‌کند. وقتی جدول/کپابیلیتی/کلاس جدیدی اضافه شد،
هم کد آن پلاگین و هم این سه رجیستری باید به‌روزرسانی شوند.

## یادداشت برندینگ (تمیزکاری انجام‌شده)

متن‌های رو به کاربر (Plugin Name، پیام‌های ایمیل، برچسب منوی ادمین) که هنوز
از نام‌های قدیمی/ناهم‌خوان («Payvand»، «Piwand»، «زوج‌درمان» به‌جای برند فعلی)
استفاده می‌کردند، به «پیوند امن» یکدست شدند. نام فایل، اسلاگ پوشه، و پیشوند
کلاس‌ها **عمداً** دست نخورده باقی ماندند چون تغییرشان یعنی نصب مجدد دستی در
وردپرس (طبق تجربه‌ی rebrand قبلی خانواده‌ی zoojdarman.ir → peyvandamn.ir).
دامنه‌ی زوج‌درمان (zoojdarman.ir) هنوز یک دیپلویمنت جدا و فعال است، پس
اصطلاح بالینی «زوج‌درمانی» (couples therapy) در برچسب‌های خدمات (نه در برند)
عمداً دست‌نخورده ماند.
