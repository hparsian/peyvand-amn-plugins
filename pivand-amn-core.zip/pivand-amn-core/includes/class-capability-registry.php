<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * رجیستری مرکزی کپابیلیتی‌های سفارشی اکوسیستم پیوند امن. الان هر پلاگین
 * جدا cap خودش را تعریف و روی نقش administrator اعمال می‌کند (zdp_manage_clients،
 * pas_manage_case_files، pas_view_all_case_files، ...) بدون هیچ نقطه‌ی
 * مرکزی برای دیدن «چه دسترسی‌ای کجا تعریف شده».
 *
 * این کلاس چیزی را خودش add_cap نمی‌کند — هر پلاگین همچنان مسئول ثبت واقعی
 * cap خودش روی نقش‌هاست (تغییرش ریسک دارد). هدف فقط مستندسازی مرکزی است تا
 * وقتی نقش سفارشی جدید (مثل «روان‌شناس» یا «منشی») ساخته می‌شود، مشخص باشد
 * دقیقاً کدام کپابیلیتی‌ها باید به آن نقش داده شوند.
 */
final class Pas_Core_Capability_Registry
{
    private static array $registered = [];

    /**
     * @param string $capability   نام دقیق کپابیلیتی (مثل 'zdp_manage_clients')
     * @param string $label        توضیح خوانا برای انسان
     * @param string $plugin_name  پلاگین صاحب این کپابیلیتی
     * @param array  $granted_to   نام نقش‌هایی که فعلاً این کپابیلیتی را دارند (مثل ['administrator'])
     */
    public static function register(string $capability, string $label, string $plugin_name, array $granted_to): void
    {
        self::$registered[] = [
            'capability'  => $capability,
            'label'       => $label,
            'plugin'      => $plugin_name,
            'granted_to'  => $granted_to,
        ];
    }

    public static function get_all(): array
    {
        return self::$registered;
    }
}
