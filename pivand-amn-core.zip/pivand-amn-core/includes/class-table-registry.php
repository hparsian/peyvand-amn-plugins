<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * رجیستری مرکزی جدول‌های دیتابیس سفارشی کل اکوسیستم پیوند امن. اکوسیستم
 * الان هفت پیشوند جدول متفاوت دارد (zdp_, psy_, pas_, pas_cf_, aco_, pwdf_,
 * payvand_) بدون قاعده‌ی مشترک — یکی‌سازی پیشوندها ریسک شکستن دیتای موجود
 * دارد، پس این کلاس فقط ثبت و نمایش می‌کند، نه تغییر.
 *
 * فایده‌ی عملی: هنگام دیباگ («این ستون کجا تعریف شده؟») یا موقع uninstall
 * کامل یک سایت، یک‌جا می‌شود دید که هر پلاگین دقیقاً چه جدول‌هایی ساخته،
 * به‌جای این‌که هر uninstall.php را جدا خواند.
 *
 * هر پلاگین با register() جدول‌های خودش را معرفی می‌کند. جدول‌های legacy
 * (مثل cpp_* که فقط برای migration یک‌باره نگه داشته شده‌اند) هم با
 * is_legacy=true ثبت می‌شوند تا در پیشخوان به‌وضوح «میراث/موقت» علامت
 * بخورند و کسی اشتباهی حذفشان نکند قبل از اتمام migration.
 */
final class Pas_Core_Table_Registry
{
    private static array $registered = [];

    /**
     * @param string   $plugin_name نام خوانا برای نمایش
     * @param string   $prefix      پیشوند جدول‌های این پلاگین (بدون $wpdb->prefix سایت)
     * @param string[] $tables      نام کامل جدول‌ها (بدون $wpdb->prefix سایت)، مثل ['zdp_bookings', 'zdp_messages']
     * @param bool     $is_legacy   اگر true باشد، این جدول‌ها میراث/موقت هستند (مثل جدول‌های cpp_* در حال migration)
     */
    public static function register(string $plugin_name, string $prefix, array $tables, bool $is_legacy = false): void
    {
        self::$registered[] = [
            'plugin'    => $plugin_name,
            'prefix'    => $prefix,
            'tables'    => $tables,
            'is_legacy' => $is_legacy,
        ];
    }

    public static function get_all(): array
    {
        return self::$registered;
    }
}
