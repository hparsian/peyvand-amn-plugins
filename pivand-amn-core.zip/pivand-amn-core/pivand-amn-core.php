<?php
/**
 * Plugin Name: پیوند امن — هسته مشترک
 * Description: زیرساخت مشترک اکوسیستم پیوند امن — توابع تکراری (نرمال‌سازی موبایل، تاریخ شمسی، IP)، بررسی وابستگی بین افزونه‌ها با هشدار واضح در پیشخوان، و رجیستری مستندشده‌ی همه‌ی قراردادهای فیلتری بین‌افزونه‌ای. این افزونه باید همیشه فعال باشد و باید قبل از بقیه‌ی افزونه‌های خانواده لود شود.
 * Version: 1.3.7
 * Requires at least: 6.6
 * Tested up to: 7.1
 * Author: Hadi.parsaeian
 * Text Domain: pivand-amn-core
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires PHP: 8.1
 * Domain Path: /languages
 *
 * ==============================================================================
 * چرا این افزونه لازم شد؟
 * با رشد اکوسیستم (client-portal، quiz-enterprise، sms-bridge، smtp-mailer،
 * content-writer، daily-feed، payvand-contact، case-file) چند بی‌نظمی جمع شده
 * بود:
 *   ۱. هفت پیشوند جدول متفاوت (zdp_, psy_, pas_, zsm_, aco_, pwdf_, payvand)
 *      بدون قاعده‌ی مشترک.
 *   ۲. نرمال‌سازی شماره موبایل و گرفتن IP واقعی مراجع، هر افزونه نسخه‌ی
 *      خودش را جدا نوشته بود.
 *   ۳. اگر یک افزونه‌ی وابسته (مثلاً sms-bridge) غیرفعال می‌شد، افزونه‌ی
 *      وابسته به آن (client-portal) بی‌صدا از کار می‌افتاد — apply_filters
 *      بدون پیاده‌سازی، فقط مقدار پیش‌فرض خالی برمی‌گرداند، بدون هیچ هشدار.
 *   ۴. قراردادهای فیلتری (pas_send_sms، psy_get_client_name_for_phone، ...)
 *      فقط در کامنت پراکنده‌ی هر پلاگین مستند بودند، نه یک‌جا.
 *
 * این افزونه این چهار مورد را حل می‌کند. تغییری در افزونه‌های موجود لازم
 * نیست — استفاده از این هسته تدریجی و اختیاری است (هر افزونه هروقت آماده
 * بود، به‌جای کد تکراری خودش، از Pas_Core_Helpers استفاده می‌کند).
 * ==============================================================================
 */

if (!defined('ABSPATH')) {
    exit;
}

define('PAS_CORE_VERSION', '1.3.7');
define('PAS_CORE_DIR', plugin_dir_path(__FILE__));
define('PAS_CORE_URL', plugin_dir_url(__FILE__));

require_once PAS_CORE_DIR . 'includes/class-helpers.php';
require_once PAS_CORE_DIR . 'includes/class-crypto.php';
require_once PAS_CORE_DIR . 'includes/class-fonts.php';
require_once PAS_CORE_DIR . 'includes/class-tokens.php';
require_once PAS_CORE_DIR . 'includes/class-jalali.php';
require_once PAS_CORE_DIR . 'includes/class-dependency-checker.php';
require_once PAS_CORE_DIR . 'includes/class-filter-registry.php';
require_once PAS_CORE_DIR . 'includes/class-table-registry.php';
require_once PAS_CORE_DIR . 'includes/class-capability-registry.php';
require_once PAS_CORE_DIR . 'includes/class-prefix-map.php';
require_once PAS_CORE_DIR . 'includes/class-admin.php';

/**
 * موقع فعال‌سازی، اگر کلید رمزنگاری از قبل جایی (wp-config.php یا فایل
 * قبلی) تنظیم نشده باشد، خودش یک کلید می‌سازد و در
 * wp-content/pas-encryption-key.php می‌نویسد — نیازی به FTP دستی نیست.
 */
register_activation_hook(__FILE__, function (): void {
    Pas_Core_Crypto::ensure_key_file();
});

add_action('plugins_loaded', function (): void {
    load_plugin_textdomain('pivand-amn-core');
    new Pas_Core_Admin();

    /**
     * ثبت وابستگی‌های شناخته‌شده‌ی اکوسیستم. هر افزونه‌ای که خودش این
     * هسته را می‌شناسد می‌تواند با همین متد وابستگی‌اش را هم ثبت کند —
     * این‌جا فقط وابستگی‌های شناخته‌شده‌ی فعلی به‌عنوان نمونه ثبت شده‌اند
     * تا از روز اول چیزی برای دیدن در پیشخوان باشد.
     */
    Pas_Core_Dependency_Checker::register(
        'پنل مراجعان',
        'pivand-amn-client-portal/pivand-amn-client-portal.php',
        ['پل پیامک (sms-bridge)', 'آزمون‌های روان‌سنجی (quiz-enterprise)']
    );
    Pas_Core_Dependency_Checker::register(
        'پل پیامک',
        'pivand-amn-sms-bridge/pivand-amn-sms-bridge.php',
        [] // خودش به چیزی وابسته نیست؛ فقط باید ثبت بشه تا وقتی غیرفعاله، پنل مراجعان هشدار بده
    );
    Pas_Core_Dependency_Checker::register(
        'آزمون‌های روان‌سنجی',
        'pivand-amn-quiz-enterprise/pivand-amn-quiz-enterprise.php',
        []
    );
    Pas_Core_Dependency_Checker::register(
        'پرونده مراجعین',
        'pivand-amn-case-file/pivand-amn-case-file.php',
        ['پنل مراجعان (اختیاری — برای اتصال حساب OTP و نوبت‌ها)']
    );

    /**
     * رجیستری جدول‌ها — فقط مستندسازی مرکزی، نه لود پویا از هر پلاگین (هنوز
     * هیچ پلاگینی خودش را با این API ثبت نمی‌کند؛ این‌جا فهرست شناخته‌شده‌ی
     * فعلی است تا از روز اول چیزی برای دیدن در پیشخوان باشد). وقتی جدول
     * جدیدی به یکی از پلاگین‌ها اضافه شد، این لیست هم باید به‌روزرسانی شود.
     */
    Pas_Core_Table_Registry::register('پنل مراجعان (client-portal)', 'zdp_', ['zdp_bookings', 'zdp_messages', 'zdp_surveys', 'zdp_leads']);
    Pas_Core_Table_Registry::register('پنل مراجعان — جدول‌های میراث در حال migration', 'cpp_', ['cpp_bookings', 'cpp_messages', 'cpp_surveys', 'cpp_leads'], true);
    Pas_Core_Table_Registry::register('پرونده مراجعین (case-file)', 'pas_cf_', ['pas_cf_cases', 'pas_cf_notes', 'pas_cf_audit_log']);
    Pas_Core_Table_Registry::register('آزمون‌های روان‌سنجی (quiz-enterprise)', 'psy_', ['psy_invitations', 'psy_attempts', 'psy_couples', 'psy_drafts', 'psy_logs']);
    Pas_Core_Table_Registry::register('پل پیامک (sms-bridge)', 'pas_', ['pas_sms_log']);
    Pas_Core_Table_Registry::register('تولید محتوا و سئو (content-writer)', 'aco_', ['aco_queue', 'aco_logs']);
    Pas_Core_Table_Registry::register('فرم تماس (payvand-contact)', 'payvand_', ['payvand_messages']);

    /**
     * رجیستری کپابیلیتی‌ها — مثل بالا، فقط مستندسازی مرکزی. اعمال واقعی
     * add_cap همچنان در همان پلاگین صاحب انجام می‌شود (تغییرش نمی‌کند).
     */
    Pas_Core_Capability_Registry::register('zdp_manage_clients', 'مدیریت مراجعین در پنل مراجعان', 'پنل مراجعان (client-portal)', ['administrator']);
    Pas_Core_Capability_Registry::register('pas_manage_case_files', 'ورود به پنل پرونده‌های بالینی (حداقلی)', 'پرونده مراجعین (case-file)', ['administrator']);
    Pas_Core_Capability_Registry::register('pas_view_all_case_files', 'دیدن پرونده‌ی همه‌ی درمانگرها، نه فقط خودش', 'پرونده مراجعین (case-file)', ['administrator']);
}, 5); // اولویت ۵ — قبل از بقیه‌ی افزونه‌های خانواده لود شود
