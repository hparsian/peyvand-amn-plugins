<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * پورت‌شده از cpp_send_sms_pattern در custom-psychology-portal، با یک رفع
 * باگ مهم: وب‌سرویس ملی پیامک تقریباً همیشه HTTP 200 برمی‌گرداند، حتی وقتی
 * ارسال واقعاً شکست خورده (اعتبار ناکافی، پترن نامعتبر، شماره مسدود و...)؛
 * نتیجه‌ی واقعی داخل بدنه‌ی JSON پاسخ، در فیلد RetStatus است (۱ = موفق).
 * نسخه‌ی قبلی فقط کد HTTP را چک می‌کرد، یعنی خطاهای منطقی ملی پیامک را
 * «موفق» تلقی می‌کرد — که یعنی کد OTP در واقع هیچ‌وقت به دست مراجع نمی‌رسید
 * ولی سیستم فکر می‌کرد ارسال شده.
 */
final class Pas_Melipayamak
{
    private const API_URL = 'https://rest.payamak-panel.com/api/SendSMS/BaseServiceNumber';

    /**
     * مرجع کدهای RetStatus ملی پیامک (طبق مستندات رسمی وب‌سرویس).
     */
    private const RET_STATUS_MESSAGES = [
        1  => 'موفق',
        2  => 'اعتبار کافی نیست',
        3  => 'محدودیت در ارسال روزانه',
        4  => 'محدودیت در حجم ارسال',
        5  => 'کد بازگشتی متن نامعتبر است',
        6  => 'شماره فرستنده نامعتبر است',
        7  => 'یکی از شماره‌های گیرنده نامعتبر است',
        9  => 'خط ارسالی فعال نیست',
        10 => 'کاربری غیرفعال است',
        11 => 'کاربری در وضعیت تعلیق است',
        12 => 'محدودیت به دلیل ارسال شکایت',
        14 => 'متن حاوی کلمه‌ی فیلترشده است',
        15 => 'محدودیت روزانه‌ی خط',
        16 => 'خطای داخلی -۱۶',
        17 => 'محدودیت زمانی بین دو ارسال از یک IP',
        35 => 'پترن یافت نشد یا تایید نشده است',
    ];

    /**
     * @param mixed $default
     * @param mixed $mobile
     * @param mixed $body_id
     * @param mixed $params
     */
    public static function handle_send_sms_filter($default, $mobile, $body_id, $params = []): bool
    {
        $mobile  = self::normalize_mobile((string) $mobile);
        $body_id = (int) $body_id;
        $params  = is_array($params) ? $params : [];

        if ($mobile === '' || $body_id <= 0) {
            Pas_Log::record($mobile, $body_id, false, 'شماره یا کد پترن نامعتبر است.');

            return false;
        }

        $username = (string) get_option('pas_sms_username', '');
        $password = (string) get_option('pas_sms_password', '');
        // unwrap_decrypt مقادیر قدیمیِ رمزنگاری‌نشده را دست‌نخورده برمی‌گرداند،
        // پس نیازی به migration دستی رمزهای فعلی نیست.
        $password = class_exists('Pas_Core_Crypto') ? Pas_Core_Crypto::unwrap_decrypt($password) : $password;

        if ($username === '' || $password === '') {
            Pas_Log::record($mobile, $body_id, false, 'نام‌کاربری/رمز ملی پیامک تنظیم نشده.');

            return false;
        }

        // ملی پیامک برای پترن‌ها placeholder نام‌دار ندارد؛ فقط ترتیب مقادیر
        // مهم است، دقیقاً همان ترتیبی که خودِ پترن در پنل ملی پیامک تعریف
        // شده. پس فقط VALUEها را (نه کلیدهای CODE/TOPIC/...) به ترتیب با
        // semicolon به هم وصل می‌کنیم.
        $text_value = implode(';', array_map('strval', array_values($params)));

        $response = wp_remote_post(self::API_URL, [
            'timeout'     => 15,
            'headers'     => ['Content-Type' => 'application/json'],
            'data_format' => 'body',
            'body'        => wp_json_encode([
                'username' => $username,
                'password' => $password,
                'text'     => $text_value,
                'to'       => $mobile,
                'bodyId'   => $body_id,
            ]),
        ]);

        if (is_wp_error($response)) {
            Pas_Log::record($mobile, $body_id, false, 'خطای اتصال: ' . $response->get_error_message());

            return false;
        }

        $http_code = wp_remote_retrieve_response_code($response);
        $body_raw  = wp_remote_retrieve_body($response);
        $decoded   = json_decode($body_raw, true);

        // ساختار پاسخ BaseServiceNumber ملی پیامک: { "Value": "...", "RetStatus": N, "StrRetStatus": "..." }
        $ret_status = isset($decoded['RetStatus']) ? (int) $decoded['RetStatus'] : null;

        if ($http_code < 200 || $http_code >= 300) {
            Pas_Log::record($mobile, $body_id, false, "کد HTTP غیرمنتظره: {$http_code}");

            return false;
        }

        if ($ret_status === 1) {
            Pas_Log::record($mobile, $body_id, true, 'ارسال موفق');

            return true;
        }

        $reason = self::RET_STATUS_MESSAGES[$ret_status] ?? ('کد نامشخص RetStatus=' . ($ret_status ?? 'null'));
        Pas_Log::record($mobile, $body_id, false, $reason);

        return false;
    }

    private static function normalize_mobile(string $mobile): string
    {
        if (class_exists('Pas_Core_Helpers')) {
            $local = Pas_Core_Helpers::normalize_mobile($mobile);
            return preg_match('/^09[0-9]{9}$/', $local) ? $local : '';
        }

        $digits = preg_replace('/\D+/', '', $mobile) ?? '';

        if (str_starts_with($digits, '0098')) {
            $digits = substr($digits, 4);
        } elseif (str_starts_with($digits, '98')) {
            $digits = substr($digits, 2);
        } elseif (str_starts_with($digits, '0')) {
            $digits = substr($digits, 1);
        }

        $local = '0' . $digits;

        return preg_match('/^09[0-9]{9}$/', $local) ? $local : '';
    }
}
